import { defineConfig } from "@playwright/test";
import dotenv from "dotenv";

dotenv.config();

const username = process.env.LT_USERNAME;
const accessKey = process.env.LT_ACCESS_KEY;

if (!username || !accessKey) {
  throw new Error("Missing LT_USERNAME or LT_ACCESS_KEY in .env");
}

const cloudWs = (capabilities: object) =>
  `wss://cdp.lambdatest.com/playwright?capabilities=${encodeURIComponent(
    JSON.stringify(capabilities)
  )}`;

export default defineConfig({
  testDir: "./tests",
  timeout: 240_000,
  use: {
    navigationTimeout: 60000,
    actionTimeout: 30000,
  },
  expect: { timeout: 15_000 },
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: 0,
  workers: 2,

  projects: [
    {
      name: "Chrome:latest:Windows 10@lambdatest",
      use: {
        viewport: { width: 1920, height: 1080 },
        connectOptions: {
          wsEndpoint: cloudWs({
            browserName: "Chrome",
            browserVersion: "latest",
            "LT:Options": {
              platform: "Windows 10",
              build: "playwright-101-assignment",
              name: "Chrome Windows test",
              user: username,
              accessKey: accessKey
            }
          })
        }
      }
    },
    {
      name: "pw-firefox:latest:macOS Catalina@lambdatest",
      use: {
        viewport: { width: 1920, height: 1080 },
        connectOptions: {
          wsEndpoint: cloudWs({
            browserName: "pw-firefox",
            browserVersion: "latest",
            "LT:Options": {
              platform: "macOS Catalina",
              build: "playwright-101-assignment",
              name: "Firefox macOS test",
              user: username,
              accessKey: accessKey
            }
          })
        }
      }
    }
    // {
    //   name: "local",
    //   use: {
    //     browserName: "chromium",
    //     headless: false,
    //     viewport: { width: 1920, height: 1080 }
    //   }
    // }
  ]
});
